﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Hospitalnew.Model;

namespace Hospitalnew
{
    public class HospitalServices
    {
        DBconnect db = new DBconnect();
        public IEnumerable<int> LoginVerification(LoginDetail ld)
        {
            return db.LoginVerification(ld);
        }
        public IEnumerable<PatientDetail> AddPatient(PatientDetail a)
        {
            return db.AddPatient(a);
        }
        public IEnumerable<PatientDetail> GetPatientDetailById(PatientDetail id)
        {
            return db.GetPatientDetailById(id);
        }
        public IEnumerable<Doctor> GetDoctorsForDropDownList()
        {
            return db.GetDoctorsForDropDownList();
        }
        public string OutPatientAppointment(OutPatientDetails op)
        {
            return db.OutPatientAppointment(op);
        }
        public string UpdateOutPatientDetails(OutPatientDetails op)
        {
            return db.UpdateOutPatientDetails(op);
        }
        public IEnumerable<OutPatientDetails> GetOutPatientDetailByDate(string opd)
        {
            return db.GetOutPatientDetailByDate(opd);
        }
        
    }

}
