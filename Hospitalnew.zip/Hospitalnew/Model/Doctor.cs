﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Hospitalnew.Model
{
    public class Doctor
    {
        public int doctorID { get; set; }
        public string doctorName { get; set; }
    }
}
