﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Hospitalnew.Model
{
    public class PatientDetail
    {
        public int patientId { get; set; }
        public string patientName { get; set; }
        public string gender { get; set; }
        public string patientAddress { get; set; }
    }
}
