﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Hospitalnew.Model
{
    public class OutPatientDetails
    {
        public int patientId { get; set; }
        public int doctorId { get; set; }
        public string consultingDate { get; set;}        
        public string consultingTime { get; set; }
        public int fee { get; set; }
        public string prescription { get; set; }
    }
}
