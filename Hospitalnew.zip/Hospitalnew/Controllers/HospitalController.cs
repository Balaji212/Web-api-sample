﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Hospitalnew.Model;

namespace Hospitalnew.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class HospitalController : ControllerBase
    {
        HospitalServices tempvariable = new HospitalServices();
        [HttpGet("GetPatientDetailById")]
        public IEnumerable<PatientDetail> GetPatientDetailById([FromQuery]PatientDetail id)
        {
            return tempvariable.GetPatientDetailById(id);
        }
        [HttpGet("GetOutPatientDetailByDate")]
        public IEnumerable<OutPatientDetails> GetOutPatientDetailByDate(string opd)
        {
            return tempvariable.GetOutPatientDetailByDate(opd);
        }

        [HttpGet("GetDoctorsForDropDownList")]
        public IEnumerable<Doctor> GetDoctorsForDropDownList()
        {
            return tempvariable.GetDoctorsForDropDownList();
        }       

        [HttpPost("AddPatient")]
        public IEnumerable<PatientDetail> AddPatient(PatientDetail pd)
        {
           return tempvariable.AddPatient(pd);           
        }
        [HttpPost("OutPatientAppointment")]
        public string OutPatientAppointment(OutPatientDetails opd)
        {
            return tempvariable.OutPatientAppointment(opd);
        }
        [HttpPut("UpdateOutPatientDetails")]
        public string UpdateOutPatientDetails(OutPatientDetails opd)
        {
            return tempvariable.UpdateOutPatientDetails(opd);
        }
    }
}
