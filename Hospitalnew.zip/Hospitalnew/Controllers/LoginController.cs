﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Hospitalnew.Model;
namespace Hospitalnew.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        // GET: api/Login
        HospitalServices tempvariable = new HospitalServices();
        [HttpGet("Login")]
        public string Login([FromQuery]LoginDetail ld)
        {
            string result = null;

            IEnumerable<int> a = tempvariable.LoginVerification(ld);
            if (a !=null )
            {
                foreach(int s in a)
                {
                    if (s == 1)
                    {
                        result = "valid user";
                    }
                    else
                        result = "Not valid user";
                }                
            }
            return result;
        }
       
    }
}
