﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Linq;
using Dapper;
using Hospitalnew.Model;

namespace Hospitalnew
{
    public class DBconnect
    {
        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\project\database.mdf;Integrated Security=True;Connect Timeout=30";
        public IEnumerable<int> LoginVerification(LoginDetail ld)
        {
            IDbConnection db = new SqlConnection(connectionString);
            return db.Query<int>("Select count(*) from AdminLogin where username=" + "'" + ld.username + "'" + "and password=" + "'" +EnryptString(ld.password) + "'");
        }
        public IEnumerable<PatientDetail> AddPatient(PatientDetail a)
        {
            int r;
            IDbConnection db = new SqlConnection(connectionString);
            string s = @"insert into Patient(patientName,gender,patientAddress) values(@patientName,@gender,@patientAddress)";
            r = db.Execute(s, new { a.patientName, a.gender, a.patientAddress });
            if (r == 1)
            {
                return db.Query<PatientDetail>("select patientId from Patient where patientAddress=" + "'" + a.patientAddress + "'");
            }
            return Enumerable.Empty<PatientDetail>();
        }
        public IEnumerable<PatientDetail> GetPatientDetailById(PatientDetail id)
        {
            IDbConnection db = new SqlConnection(connectionString);

            return db.Query<PatientDetail>("select * from Patient where patientId=" + id.patientId);
        }
        public IEnumerable<Doctor> GetDoctorsForDropDownList()
        {
            IDbConnection db = new SqlConnection(connectionString);
            return db.Query<Doctor>("select * from Doctor");
        }
        public string OutPatientAppointment(OutPatientDetails op)
        {
            int r;
            IDbConnection db = new SqlConnection(connectionString);
            string s = @"insert into Appointment(patientId,doctorId,consultingDate,consultingTime,fee) values(@patientId,@doctorId,@consultingDate,@consultingTime,@fee)";
            r = db.Execute(s, op);
            if (r == 1)
            {
                return "Appointment Booked";
            }
            else
                return "Check the entered values";
        }
        public string UpdateOutPatientDetails(OutPatientDetails op)
        {
            IDbConnection db = new SqlConnection(connectionString);
            string s = @"update Appointment set prescription=@prescription where patientId=@patientId";
            int r = db.Execute(s, new { op.prescription, op.patientId });
            string r1 = null;
            if (r == 1)
            {
                r1 = "Updated Successfully";
            }
            else
                r1 = "Error";
            return r1;
        }
        public IEnumerable<OutPatientDetails> GetOutPatientDetailByDate(string opd)
        {
            IDbConnection db = new SqlConnection(connectionString);

            return db.Query<OutPatientDetails>("select * from Appointment where consultingDate=" + "'" + opd + "'");
        }
        public string EnryptString(string strEncrypted)
        {
            byte[] b = System.Text.ASCIIEncoding.ASCII.GetBytes(strEncrypted);
            string encrypted = Convert.ToBase64String(b);
            return encrypted;
        }
        
    }
}
